# Stepper-motor-linear-speed-controller

the implementation of a linear speed controller for a stepper motor. The algorithm used in generating this linear speed profile is 
taken from this article:“Generate stepper-motor speed profiles in real time” posted by David Austin.

The firmware was on implemented on a an ARM7 LPC2378. The development board MCB2370 was used to validate and test the code.
